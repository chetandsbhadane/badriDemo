// server.js
const express = require('express');
const app = express();
const port = 3000;

// Sample data
let events = [
    { title: "Event 1", description: "This is the first event", dueDate: "2024-08-01" },
    { title: "Event 2", description: "This is the second event", dueDate: "2024-08-02" }
];

app.use(express.json());

// Manually set CORS headers
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*'); // Allow all origins
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    if (req.method === 'OPTIONS') {
        return res.sendStatus(204); // No Content
    }
    next();
});

// POST /new -> Add new event
app.post('/new', (req, res) => {
    const event = req.body;
    events.push(event);
    res.status(201).send('Event added');
});

// GET /list -> List all events
app.get('/list', (req, res) => {
    res.json(events);
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
