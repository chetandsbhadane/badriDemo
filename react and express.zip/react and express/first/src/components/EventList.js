// EventList.js
import React from 'react';

function EventList({ events }) {
    return (
        <table className="table">
            <thead>
                <tr>
                    <th>Event Title</th>
                    <th>Description</th>
                    <th>Due Date</th>
                </tr>
            </thead>
            <tbody>
                {events.map((event, index) => (
                    <tr key={index}>
                        <td>{event.title}</td>
                        <td>{event.description}</td>
                        <td>{event.dueDate}</td>
                    </tr>
                ))}
            </tbody>
        </table>
    );
}

export default EventList;
