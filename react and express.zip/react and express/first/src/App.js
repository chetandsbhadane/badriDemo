// App.js
import React, { useState, useEffect } from 'react';

import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';
import AddEvent from './components/AddEvent';
import EventList from './components/EventList';

function App() {
    const [events, setEvents] = useState([]);

    const fetchEvents = async () => {
        try {
            const response = await axios.get('http://localhost:3000/list');
            setEvents(response.data);
        } catch (error) {
            console.error('Error fetching events:', error);
        }
    };

    useEffect(() => {
        fetchEvents();
    }, []);

    return (
        <div className="container mt-5">
            <h1>Event Management</h1>
            <AddEvent fetchEvents={fetchEvents} />
            <EventList events={events} />
        </div>
    );
}

export default App;
